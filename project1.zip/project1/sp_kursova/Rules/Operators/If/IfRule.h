#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeIf(std::shared_ptr<Controller> controller);